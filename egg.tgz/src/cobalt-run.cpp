// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dispatch cobalt jobs"); }
int main(){
  announce();
  return lionss_run_workload("cobalt-run");
}
