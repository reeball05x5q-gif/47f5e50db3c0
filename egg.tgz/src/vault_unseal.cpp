// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Unseal key shares\n", stdout);
  return lionss_run_workload("vault_unseal");
}
