// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reconcile application\n", stdout);
  return lionss_run_workload("argocd_sync2");
}
